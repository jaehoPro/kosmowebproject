package vocabularyList;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.LayoutStyle.ComponentPlacement;

public class WordAdd extends JPanel {

	/**
	 * Create the panel.
	 */
	ArrayList<VO> list=new ArrayList<VO>();
	
	public WordAdd(VO addVoca) {
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		
		panel.setBounds(300, 300, 550, 400);
		
		add(panel, BorderLayout.CENTER);
		
		JButton btn_add = new JButton("등  록");
		
		JTextArea voca_means = new JTextArea();
		voca_means.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				int keycode = e.getKeyCode();
				if(keycode == e.VK_TAB)
				{
					btn_add.requestFocus();
				}
			}
		});
		voca_means.setFont(new Font("Monospaced", Font.PLAIN, 20));
		
		JTextArea voca_spell = new JTextArea();
		voca_spell.setFont(new Font("Monospaced", Font.PLAIN, 20));
		voca_spell.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				//if(e.getKeyCode()==KeyEvent.VK_TAB) {
					
				int keycode = e.getKeyCode();
				if(keycode == e.VK_TAB)
				{
					voca_means.requestFocus();
				}
			}
		});
		
		
		JButton btn_reset = new JButton("초기화");
		btn_reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				voca_spell.setText("");
				voca_means.setText("");
			}
		});
		
		
		btn_add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int res = 0;
				
				addVoca.setVoca_spell(voca_spell.getText());		//단어 스펠을 VO 입력
				addVoca.setVoca_means(voca_means.getText());		//단어 뜻을 VO 입력
				
				if(voca_spell.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "단어를 입력해주세요.");
					return;
				}
				else if(voca_means.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "단어의 뜻을 입력해주세요.");
					return;
				}
				
				JDBC jdbc = new JDBC();
				res=jdbc.vocaAdd(addVoca);
				if(res==1)
				{
					JOptionPane.showMessageDialog(null, "등록완료되었습니다.");
					voca_spell.setText("");
					voca_means.setText("");
					voca_spell.requestFocus();
				}
				
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(25)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(voca_spell, GroupLayout.PREFERRED_SIZE, 183, GroupLayout.PREFERRED_SIZE)
						.addComponent(btn_add))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(voca_means, GroupLayout.PREFERRED_SIZE, 183, GroupLayout.PREFERRED_SIZE)
						.addComponent(btn_reset))
					.addContainerGap(41, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(57)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(voca_spell, GroupLayout.PREFERRED_SIZE, 173, GroupLayout.PREFERRED_SIZE)
						.addComponent(voca_means, GroupLayout.PREFERRED_SIZE, 173, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btn_reset)
						.addComponent(btn_add))
					.addContainerGap(29, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);

	}
}
