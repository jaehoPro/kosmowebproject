package vocabularyList;

public class VO {
	
	int book_num;
    String book_name;
    
    int voca_num;
    String voca_spell;
    String voca_means;
    String voca_date;
    int voca_memory;
    int voca_count=0;
	
	public int getVoca_count() {
		return voca_count;
	}
	public void setVoca_count(int voca_count) {
		this.voca_count = voca_count;
	}
	public int getBook_num() {
		return book_num;
	}
	public void setBook_num(int book_num) {
		this.book_num = book_num;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public int getVoca_num() {
		return voca_num;
	}
	public void setVoca_num(int voca_num) {
		this.voca_num = voca_num;
	}
	public String getVoca_spell() {
		return voca_spell;
	}
	public void setVoca_spell(String voca_spell) {
		this.voca_spell = voca_spell;
	}
	public String getVoca_means() {
		return voca_means;
	}
	public void setVoca_means(String voca_means) {
		this.voca_means = voca_means;
	}
	public String getVoca_date() {
		return voca_date;
	}
	public void setVoca_date(String voca_date) {
		this.voca_date = voca_date;
	}
	public int getVoca_memory() {
		return voca_memory;
	}
	public void setVoca_memory(int voca_memory) {
		this.voca_memory = voca_memory;
	}
	
       

}
